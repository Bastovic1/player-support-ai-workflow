# Player Support Copilot — Workflow Prototype

A small learning project exploring how AI can support a gaming customer-support workflow: ticket categorization, priority suggestions, empathetic reply drafting, and internal handoff notes.

## Run it
Open `index.html` in a modern browser. No installation or server is required.

## What it demonstrates
- A simple ticket intake interface
- Suggested category and priority
- Draft response in English or Arabic
- Internal handoff note and text export
- Structured prompt builder for testing with an LLM
- Human review and privacy guardrails

## Important limitation
The interactive demo currently uses transparent keyword-based rules for classification and prewritten response patterns. It does **not** call an external AI model. The prompt builder creates a prompt that can be tested in an LLM. This is an honest first prototype, not a production AI support system.

## Next step toward a real AI integration
Connect the prompt to an approved LLM through a server-side endpoint, keep API keys on the server (never in browser code), use fictional/anonymized test tickets, and evaluate category accuracy and response quality before any real deployment.

## Safety principles
- Never paste real customer data into a public demo.
- Never ask for passwords or full payment-card details.
- Do not promise refunds, item restoration, or enforcement outcomes without verification.
- Keep a human agent responsible for decisions and sending replies.

## Public demo hosting
This is a static website and can be published with a static host such as GitHub Pages. Upload the project files to a repository and enable Pages for the branch/root folder. The project has not been published online by this package; a public URL will exist only after you deploy it.

Independent learning project. Not affiliated with Process Street or any game publisher.
